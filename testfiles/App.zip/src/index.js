console.log('This is just some application code. It does nothing');
