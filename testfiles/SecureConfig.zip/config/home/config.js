// Simulated config file
//
module.exports.dbExport = {
	host: 'endpoint.database.com',
	port: 123,
	name: 'myDB'
};
